// Fungsi bantu murni (tanpa state) agar component tetap ringkas.

export const LOW_STOCK = 5;      // stok <= 5 dianggap menipis
export const MAX_STOCK_BAR = 50; // stok 50 = bar penuh

export const formatRupiah = (n) =>
  new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0,
  }).format(n);

export const getStockLevel = (stok) => {
  if (stok === 0) return "habis";
  if (stok <= LOW_STOCK) return "menipis";
  return "aman";
};

export const STOCK_LABEL = { habis: "Habis", menipis: "Menipis", aman: "Aman" };
