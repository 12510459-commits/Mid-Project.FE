import { useEffect, useMemo, useState } from "react";
import { CATEGORIES, initialProducts } from "./data/products.js";
import { LOW_STOCK } from "./utils/helpers.js";
import Navbar from "./components/Navbar.jsx";
import StatsSummary from "./components/StatsSummary.jsx";
import ProductList from "./components/ProductList.jsx";
import ProductForm from "./components/ProductForm.jsx";
import ConfirmDialog from "./components/ConfirmDialog.jsx";
import SummaryPage from "./components/SummaryPage.jsx";

export default function App() {
  // ===== STATE =====
  const [products, setProducts] = useState(initialProducts);
  const [page, setPage] = useState("produk");
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("Semua");
  const [sort, setSort] = useState("default");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);       // produk yang sedang diubah (null = mode tambah)
  const [deleteTarget, setDeleteTarget] = useState(null); // produk yang akan dihapus
  const [toast, setToast] = useState("");

  // Toast hilang otomatis; timer dibersihkan agar notifikasi baru tidak tertutup timer lama.
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(""), 2500);
    return () => clearTimeout(t);
  }, [toast]);

  const notify = (message) => setToast(message);

  // ===== DATA TURUNAN (dihitung dari state, tidak disimpan ulang) =====
  const visibleProducts = useMemo(() => {
    const q = query.trim().toLowerCase();
    const result = products.filter(
      (p) =>
        p.nama.toLowerCase().includes(q) &&
        (category === "Semua" || p.kategori === category)
    );
    if (sort === "harga-asc") result.sort((a, b) => a.harga - b.harga);
    if (sort === "harga-desc") result.sort((a, b) => b.harga - a.harga);
    if (sort === "stok-asc") result.sort((a, b) => a.stok - b.stok);
    return result;
  }, [products, query, category, sort]);

  const restockItems = products.filter((p) => p.stok <= LOW_STOCK);
  const inventoryValue = products.reduce((sum, p) => sum + p.harga * p.stok, 0);
  const inactiveCount = products.filter((p) => !p.aktif).length;

  // ===== EVENT HANDLER =====
  const openAdd = () => {
    setEditing(null);
    setFormOpen(true);
  };

  const openEdit = (product) => {
    setEditing(product);
    setFormOpen(true);
  };

  const handleSave = (data) => {
    if (editing) {
      setProducts((prev) => prev.map((p) => (p.id === editing.id ? { ...p, ...data } : p)));
      notify("Produk diperbarui");
    } else {
      setProducts((prev) => [{ ...data, id: Date.now(), aktif: true }, ...prev]);
      notify("Produk ditambahkan");
    }
    setFormOpen(false);
    setEditing(null);
  };

  const handleDelete = () => {
    setProducts((prev) => prev.filter((p) => p.id !== deleteTarget.id));
    setDeleteTarget(null);
    notify("Produk dihapus");
  };

  const handleStock = (id, delta) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, stok: Math.max(0, p.stok + delta) } : p))
    );
  };

  const handleToggle = (id) => {
    setProducts((prev) => prev.map((p) => (p.id === id ? { ...p, aktif: !p.aktif } : p)));
  };

  // ===== TAMPILAN =====
  return (
    <>
      <Navbar
        page={page}
        onNavigate={setPage}
        onAdd={openAdd}
        restockCount={restockItems.length}
      />

      <main className="content">
        <div className="page-title">
          <h1>{page === "produk" ? "Daftar produk" : "Ringkasan persediaan"}</h1>
          <p className="muted">
            {page === "produk"
              ? `Menampilkan ${visibleProducts.length} dari ${products.length} produk`
              : "Pantau nilai stok dan produk yang hampir habis"}
          </p>
        </div>

        <StatsSummary
          total={products.length}
          inventoryValue={inventoryValue}
          restock={restockItems.length}
          inactive={inactiveCount}
        />

        {page === "produk" ? (
          <ProductList
            products={visibleProducts}
            categories={CATEGORIES}
            query={query} onQueryChange={setQuery}
            category={category} onCategoryChange={setCategory}
            sort={sort} onSortChange={setSort}
            onEdit={openEdit}
            onDelete={setDeleteTarget}
            onStock={handleStock}
            onToggle={handleToggle}
          />
        ) : (
          <SummaryPage
            products={products}
            categories={CATEGORIES}
            restockItems={restockItems}
            onStock={handleStock}
          />
        )}
      </main>

      {formOpen && (
        <ProductForm
          initial={editing}
          categories={CATEGORIES}
          onSubmit={handleSave}
          onClose={() => setFormOpen(false)}
        />
      )}
      {deleteTarget && (
        <ConfirmDialog
          title="Hapus produk?"
          message={`"${deleteTarget.nama}" akan dihapus dari daftar.`}
          confirmLabel="Hapus produk"
          onConfirm={handleDelete}
          onCancel={() => setDeleteTarget(null)}
        />
      )}
      {toast && (
        <div className="toast" role="status">
          {toast}
        </div>
      )}
    </>
  );
}
