import { CATEGORY_COLORS } from "../data/products.js";
import { MAX_STOCK_BAR, STOCK_LABEL, formatRupiah, getStockLevel } from "../utils/helpers.js";

// Component: satu baris produk (termasuk pengatur stok + / -).
// Semua aksi dikirim ke App lewat props (callback).
export default function ProductRow({ product, onEdit, onDelete, onStock, onToggle }) {
  const { id, nama, kategori, harga, stok, aktif } = product;
  const level = getStockLevel(stok);
  const pct = Math.min(100, (stok / MAX_STOCK_BAR) * 100);

  return (
    <li className={`row ${aktif ? "" : "inactive"}`}>
      <div className="cell cell-name">
        <span className="tile" style={{ background: CATEGORY_COLORS[kategori] }} aria-hidden="true">
          {nama.charAt(0)}
        </span>
        <div>
          <strong>{nama}</strong>
          <span className="sub">{kategori}</span>
        </div>
      </div>

      <div className="cell cell-price" data-label="Harga">{formatRupiah(harga)}</div>

      <div className="cell" data-label="Stok">
        <div className="stock">
          <div className="stock-line">
            <button
              className="step"
              onClick={() => onStock(id, -1)}
              disabled={stok === 0}
              aria-label="Kurangi stok"
            >
              −
            </button>
            <strong className="stock-num">{stok}</strong>
            <button className="step" onClick={() => onStock(id, 1)} aria-label="Tambah stok">
              +
            </button>
            <span className={`level ${level}`}>{STOCK_LABEL[level]}</span>
          </div>
          <div className="bar" aria-hidden="true">
            <div className={`bar-fill ${level}`} style={{ width: `${pct}%` }} />
          </div>
        </div>
      </div>

      <div className="cell" data-label="Status">
        <button
          role="switch"
          aria-checked={aktif}
          className={`switch ${aktif ? "on" : ""}`}
          onClick={() => onToggle(id)}
        >
          <span className="knob" />
          <span className="switch-text">{aktif ? "Aktif" : "Nonaktif"}</span>
        </button>
      </div>

      <div className="cell cell-actions">
        <button className="btn ghost small" onClick={() => onEdit(product)}>Ubah</button>
        <button className="btn danger small" onClick={() => onDelete(product)}>Hapus</button>
      </div>
    </li>
  );
}
