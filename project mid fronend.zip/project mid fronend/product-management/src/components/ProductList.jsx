import ProductRow from "./ProductRow.jsx";

// Component: toolbar (cari, filter, urutkan) + daftar produk.
// Event: onChange. List rendering: map(). Conditional rendering: kondisi kosong.
export default function ProductList({
  products,
  categories,
  query, onQueryChange,
  category, onCategoryChange,
  sort, onSortChange,
  onEdit, onDelete, onStock, onToggle,
}) {
  return (
    <>
      <div className="toolbar">
        <input
          type="search"
          placeholder="Cari nama produk"
          value={query}
          onChange={(e) => onQueryChange(e.target.value)}
          aria-label="Cari produk"
        />
        <select value={category} onChange={(e) => onCategoryChange(e.target.value)} aria-label="Filter kategori">
          <option value="Semua">Semua kategori</option>
          {categories.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
        <select value={sort} onChange={(e) => onSortChange(e.target.value)} aria-label="Urutkan">
          <option value="default">Urutan awal</option>
          <option value="harga-asc">Harga termurah</option>
          <option value="harga-desc">Harga termahal</option>
          <option value="stok-asc">Stok tersedikit</option>
        </select>
      </div>

      {products.length === 0 ? (
        <div className="empty">
          <strong>Tidak ada produk yang cocok</strong>
          <p>Ubah kata kunci atau filter, atau tambahkan produk baru.</p>
        </div>
      ) : (
        <div className="list">
          <div className="row head" aria-hidden="true">
            <span>Produk</span>
            <span>Harga</span>
            <span>Stok</span>
            <span>Status</span>
            <span />
          </div>
          <ul>
            {products.map((p) => (
              <ProductRow
                key={p.id}
                product={p}
                onEdit={onEdit}
                onDelete={onDelete}
                onStock={onStock}
                onToggle={onToggle}
              />
            ))}
          </ul>
        </div>
      )}
    </>
  );
}
