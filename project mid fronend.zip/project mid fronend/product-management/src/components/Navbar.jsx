// Component: bar navigasi atas. Props: page, onNavigate, onAdd, restockCount.
export default function Navbar({ page, onNavigate, onAdd, restockCount }) {
  const tabs = [
    { key: "produk", label: "Produk" },
    { key: "ringkasan", label: "Ringkasan", badge: restockCount },
  ];

  return (
    <header className="navbar">
      <div className="brand">
        <span className="brand-mark" aria-hidden="true" />
        <strong>Etalase</strong>
      </div>

      <nav aria-label="Menu utama" className="tabs">
        {tabs.map((t) => (
          <button
            key={t.key}
            className={`tab ${page === t.key ? "active" : ""}`}
            onClick={() => onNavigate(t.key)}
            aria-current={page === t.key ? "page" : undefined}
          >
            {t.label}
            {t.badge > 0 && <span className="badge">{t.badge}</span>}
          </button>
        ))}
      </nav>

      <button className="btn primary" onClick={onAdd}>Tambah produk</button>
    </header>
  );
}
