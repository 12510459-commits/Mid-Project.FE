import { formatRupiah } from "../utils/helpers.js";

// Component: kartu statistik. Nilainya dihitung di App, dikirim lewat props.
export default function StatsSummary({ total, inventoryValue, restock, inactive }) {
  const stats = [
    { label: "Total produk", value: total },
    { label: "Nilai persediaan", value: formatRupiah(inventoryValue) },
    { label: "Perlu restock", value: restock, warn: restock > 0 },
    { label: "Nonaktif", value: inactive },
  ];

  return (
    <section className="stats" aria-label="Ringkasan produk">
      {stats.map((s) => (
        <div className={`stat ${s.warn ? "warn" : ""}`} key={s.label}>
          <span className="stat-label">{s.label}</span>
          <span className="stat-value">{s.value}</span>
        </div>
      ))}
    </section>
  );
}
