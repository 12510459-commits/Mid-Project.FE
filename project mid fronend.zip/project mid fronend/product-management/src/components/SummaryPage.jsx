import { CATEGORY_COLORS } from "../data/products.js";
import { STOCK_LABEL, formatRupiah, getStockLevel } from "../utils/helpers.js";

// Component: halaman Ringkasan = nilai persediaan per kategori + daftar perlu restock.
// Data diolah di sini dari props.
export default function SummaryPage({ products, categories, restockItems, onStock }) {
  const rows = categories.map((c) => {
    const items = products.filter((p) => p.kategori === c);
    return {
      kategori: c,
      jumlah: items.length,
      stok: items.reduce((sum, p) => sum + p.stok, 0),
      nilai: items.reduce((sum, p) => sum + p.harga * p.stok, 0),
    };
  });
  const maxValue = Math.max(...rows.map((r) => r.nilai), 1);

  return (
    <div className="two-col">
      <section className="panel">
        <h2>Nilai persediaan per kategori</h2>
        <ul className="cat-list">
          {rows.map((r) => (
            <li key={r.kategori}>
              <div className="cat-head">
                <span>
                  <i className="dot" style={{ background: CATEGORY_COLORS[r.kategori] }} aria-hidden="true" />
                  {r.kategori}
                </span>
                <strong>{formatRupiah(r.nilai)}</strong>
              </div>
              <div className="bar" aria-hidden="true">
                <div
                  className="bar-fill"
                  style={{ width: `${(r.nilai / maxValue) * 100}%`, background: CATEGORY_COLORS[r.kategori] }}
                />
              </div>
              <span className="sub">{r.jumlah} produk, {r.stok} unit</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="panel">
        <h2>Perlu restock</h2>
        {restockItems.length === 0 ? (
          <p className="muted">Semua stok aman.</p>
        ) : (
          <ul className="restock">
            {restockItems.map((p) => {
              const level = getStockLevel(p.stok);
              return (
                <li key={p.id}>
                  <div>
                    <strong>{p.nama}</strong>
                    <span className="sub">
                      Sisa {p.stok} unit <span className={`level ${level}`}>{STOCK_LABEL[level]}</span>
                    </span>
                  </div>
                  <button className="btn primary small" onClick={() => onStock(p.id, 10)}>
                    Tambah 10
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </div>
  );
}
