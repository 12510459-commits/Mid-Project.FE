import { useState } from "react";

// Component: form tambah/ubah produk (modal). State lokal untuk isi form dan error.
export default function ProductForm({ initial, categories, onSubmit, onClose }) {
  const isEdit = Boolean(initial);
  const [form, setForm] = useState(
    initial
      ? { nama: initial.nama, kategori: initial.kategori, harga: String(initial.harga), stok: String(initial.stok) }
      : { nama: "", kategori: categories[0], harga: "", stok: "" }
  );
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    const err = {};
    if (!form.nama.trim()) err.nama = "Nama produk wajib diisi.";
    if (!(Number(form.harga) > 0)) err.harga = "Harga harus lebih dari 0.";
    if (form.stok === "" || Number(form.stok) < 0) err.stok = "Stok tidak boleh kosong atau negatif.";
    return err;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const err = validate();
    setErrors(err);
    if (Object.keys(err).length > 0) return;
    onSubmit({
      nama: form.nama.trim(),
      kategori: form.kategori,
      harga: Number(form.harga),
      stok: Math.floor(Number(form.stok)),
    });
  };

  return (
    <div className="overlay" onClick={onClose}>
      <form className="modal" onSubmit={handleSubmit} onClick={(e) => e.stopPropagation()} noValidate>
        <h2>{isEdit ? "Ubah produk" : "Tambah produk"}</h2>

        <label>
          Nama produk
          <input name="nama" value={form.nama} onChange={handleChange} autoFocus />
          {errors.nama && <span className="error" role="alert">{errors.nama}</span>}
        </label>

        <label>
          Kategori
          <select name="kategori" value={form.kategori} onChange={handleChange}>
            {categories.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </label>

        <div className="two">
          <label>
            Harga (Rp)
            <input name="harga" type="number" min="0" value={form.harga} onChange={handleChange} />
            {errors.harga && <span className="error" role="alert">{errors.harga}</span>}
          </label>
          <label>
            Stok
            <input name="stok" type="number" min="0" value={form.stok} onChange={handleChange} />
            {errors.stok && <span className="error" role="alert">{errors.stok}</span>}
          </label>
        </div>

        <div className="modal-actions">
          <button type="button" className="btn ghost" onClick={onClose}>Batal</button>
          <button type="submit" className="btn primary">{isEdit ? "Simpan perubahan" : "Tambah produk"}</button>
        </div>
      </form>
    </div>
  );
}
