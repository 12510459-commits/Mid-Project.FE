// Dummy data + konstanta. Belum memakai backend/database (sesuai ketentuan Project Mid).

export const CATEGORIES = ["Elektronik", "Fashion", "Makanan", "Rumah Tangga", "Alat Tulis"];

// Warna penanda kategori
export const CATEGORY_COLORS = {
  Elektronik: "#2F5BB8",
  Fashion: "#9A3F7A",
  Makanan: "#B5651D",
  "Rumah Tangga": "#0E7A6B",
  "Alat Tulis": "#5B6472",
};

export const initialProducts = [
  { id: 1, nama: "Headphone Nirkabel Aura", kategori: "Elektronik", harga: 450000, stok: 24, aktif: true },
  { id: 2, nama: "Power Bank 10.000 mAh", kategori: "Elektronik", harga: 185000, stok: 4, aktif: true },
  { id: 3, nama: "Kaos Polos Katun", kategori: "Fashion", harga: 65000, stok: 48, aktif: true },
  { id: 4, nama: "Jaket Hoodie Fleece", kategori: "Fashion", harga: 210000, stok: 0, aktif: true },
  { id: 5, nama: "Kopi Arabika 250 g", kategori: "Makanan", harga: 78000, stok: 30, aktif: true },
  { id: 6, nama: "Granola Madu 500 g", kategori: "Makanan", harga: 55000, stok: 3, aktif: false },
  { id: 7, nama: "Botol Minum Stainless", kategori: "Rumah Tangga", harga: 95000, stok: 18, aktif: true },
  { id: 8, nama: "Lampu Meja LED", kategori: "Rumah Tangga", harga: 120000, stok: 9, aktif: true },
  { id: 9, nama: "Buku Catatan A5 (isi 3)", kategori: "Alat Tulis", harga: 42000, stok: 60, aktif: true },
  { id: 10, nama: "Pulpen Gel Hitam (lusin)", kategori: "Alat Tulis", harga: 36000, stok: 5, aktif: true },
];
